using UnityEngine;

public class PlayerHealth : HealthComponent
{
    [Header("Player Life System")]
    [SerializeField] private HealthSystem livesSystem;
    [SerializeField] private PlayerMovement playerMovement;

    protected override void Awake()
    {
        base.Awake();

        if (livesSystem == null)
        {
            livesSystem = GetComponent<HealthSystem>();
        }

        if (playerMovement == null)
        {
            playerMovement = GetComponent<PlayerMovement>();
        }
    }

    protected override void Die()
    {
        if (IsDead)
            return;

        base.Die();

        if (livesSystem != null && livesSystem.CurrentLives > 0)
        {
            livesSystem.LoseLife();

            if (livesSystem.CurrentLives < 0)
            {
                livesSystem.OnGameOver?.Invoke();
            }
        }
    }

    private void Respawn()
    {
        ResetHealth();

        if (playerMovement != null)
        {
            playerMovement.Respawn();
        }

        Debug.Log("Player respawned!");
    }

    public void ResetForNewGame()
    {
        if (livesSystem != null)
        {
            livesSystem.ResetLives();
        }
        ResetHealth();
    }
}
